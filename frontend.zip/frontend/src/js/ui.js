/**
 * ui.js - The Presentation Layer
 * This file is responsible for DOM manipulation and rendering.
 * It receives data and renders it as HTML.
 * It does NOT make API calls or contain business logic.
 */

/**
 * Renders the login form
 */
export function renderLogin() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="login-container">
      <!-- Left Panel -->
      <div class="left-panel">
        <img src="/public/images/logo.png" alt="Riwi Logo" class="riwi-logo" />
        <h1 class="form-title">Welcome Back!</h1>
        <p class="form-text">Please enter your details to sign in.</p>
        <form id="loginForm">
          <input type="text" id="username" class="form-control" placeholder="Username" required />
          <div class="password-field">
            <input type="password" id="password" class="form-control" placeholder="Password" required />
            <img src="/public/images/show-password.svg" alt="Show password" id="togglePassword" class="toggle-password-icon" />
          </div>
          <a href="#" class="forgot-password">Forgot password?</a>
          <button type="submit" class="btn-login">Login</button>
        </form>
      </div>

      <!-- Right Panel -->
      <div class="right-panel">
        <h1 class="welcome-text-right">
          Riwi <span class="riwi-text-gradient">Team</span>
        </h1>
        <img src="/public/images/illustration.png" alt="Riwi Team" class="full-illustration" />
      </div>
    </div>
  `;
}

/**
 * Renders the requests table
 * @param {Array} requests
 */
export function renderRequestsTable(requests) {
  const container = document.getElementById('dynamic-content');
  if (!container) return;

  container.innerHTML = `
    <section class="content-section">
      <h2>Requests List</h2>
      <table class="data-table" id="requestsTable">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Type</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="requestsTableBody">
          <!-- Aquí se renderizarán las solicitudes -->
        </tbody>
      </table>
    </section>
  `;

  const tbody = document.getElementById('requestsTableBody');
  if (!tbody) return;

  if (requests.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" style="text-align: center; padding: 20px; color: #666;">
          No pending requests.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = requests.map(req => `
    <tr>
      <td>
        <img src="/public/images/user-avatar.png" alt="User" class="user-avatar" />
        ${req.employee}
      </td>
      <td>${req.type}</td>
      <td>${req.date}</td>
      <td><span class="status status-pending">${req.status}</span></td>
      <td class="actions">
        <button class="edit-btn" data-id="${req.id}">✎</button>
        <button class="delete-btn" data-id="${req.id}">🗑️</button>
      </td>
    </tr>
  `).join('');
}