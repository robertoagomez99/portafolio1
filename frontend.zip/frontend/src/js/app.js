/**
 * app.js - The Orchestration Director
 * This file is responsible for:
 * - Event listeners
 * - API calls (via api.js)
 * - UI rendering (via ui.js)
 * - Orchestrate the login flow and authentication
 */

import { renderLogin } from './ui.js';
import { login } from './api.js';
import { requireAuth } from './guard.js';

document.addEventListener('DOMContentLoaded', () => {
  const path = window.location.pathname;

  // === Verificar sesión al cargar cualquier página ===
  const token = localStorage.getItem('authToken');
  const user = localStorage.getItem('user');

  // Si el usuario ya está autenticado
  if (token && user) {
    // Si está en el login, redirigir al dashboard
    if (path.includes('index.html') || path === '/' || path === '/index.html') {
      window.location.href = '/src/dashboard.html';
      return;
    }
  }

  // Si está en el dashboard, proteger acceso
  if (path.includes('dashboard.html')) {
    requireAuth();
    return;
  }

  // Si está en el login y no hay sesión, mostrar formulario
  if (path.includes('index.html') || path === '/' || path === '/index.html') {
    renderLogin();
    setupLoginForm();
    setupPasswordToggle();
  }
});

/**
 * Sets up the login form submission
 */
function setupLoginForm() {
  const loginForm = document.getElementById('loginForm');
  if (!loginForm) return;

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    if (!username || !password) {
      alert('Please fill in all fields.');
      return;
    }

    try {
      const response = await login(username, password);

      if (response.success) {
        localStorage.setItem('authToken', response.token);
        localStorage.setItem('user', JSON.stringify(response.user));
        redirectToDashboard(response.user.role);
      } else {
        alert(response.message || 'Invalid credentials');
      }
    } catch (error) {
      console.error('Login error:', error);
      alert('Connection failed. Please try again later.');
    }
  });
}

/**
 * Toggles password visibility
 */
function setupPasswordToggle() {
  const togglePassword = document.getElementById('togglePassword');
  const passwordInput = document.getElementById('password');

  if (!togglePassword || !passwordInput) return;

  togglePassword.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    togglePassword.src = isPassword 
      ? '/public/images/hide-password.svg' 
      : '/public/images/show-password.svg';
  });

  togglePassword.src = '/public/images/show-password.svg';
}

/**
 * Redirects the user to the appropriate dashboard
 * @param {string} role
 */
function redirectToDashboard(role) {
  const roleLabels = {
    employee: 'Employee Dashboard',
    leader: 'Team Leader Dashboard',
    hr: 'Human Resources Dashboard'
  };

  const label = roleLabels[role] || 'Dashboard';
  alert(`Login successful! Welcome to the ${label}.`);
  window.location.href = '/src/dashboard.html';
}