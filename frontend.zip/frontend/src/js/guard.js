/**
 * guard.js - The Frontend Guardian
 * This file is responsible for:
 * - Preventing unauthorized access to protected routes
 * - Showing a secure loading screen to avoid UI flash
 * - Redirecting to login if no session exists
 */

// Referencia al overlay
const guardOverlay = document.getElementById('guardOverlay');
const appContainer = document.getElementById('app');

/**
 * requireAuth - Checks if the user is authenticated
 * Shows a secure overlay until validation is complete
 */
export function requireAuth() {
  // Aseguramos que el overlay esté visible
  if (guardOverlay) {
    guardOverlay.style.display = 'flex';
  }

  // Damos prioridad a la validación
  setTimeout(() => {
    const token = localStorage.getItem('authToken');
    const user = localStorage.getItem('user');

    if (!token || !user) {
      console.warn('Acceso denegado: No hay sesión activa');
      window.location.replace('/index.html');
      return;
    }

    // Si está autenticado, ocultar overlay y mostrar app
    if (guardOverlay && appContainer) {
      guardOverlay.style.opacity = 0;
      setTimeout(() => {
        guardOverlay.style.display = 'none';
        appContainer.style.display = 'block';
      }, 300);
    }
  }, 10); // Pequeño delay para asegurar que el DOM esté listo
}

/**
 * logout - Clears session and redirects to login
 */
export function logout() {
  localStorage.removeItem('authToken');
  localStorage.removeItem('user');
  window.location.replace('/index.html');
}