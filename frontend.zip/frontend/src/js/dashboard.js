/**
 * dashboard.js - The Orchestration Director
 * This file is responsible for:
 * - Event listeners
 * - API calls (via api.js)
 * - UI rendering (via ui.js)
 * - Orchestrate the admin dashboard flow
 */

import { apiRequest } from './api.js';
import { renderRequestsTable } from './ui.js';

document.addEventListener('DOMContentLoaded', () => {
  // Step 1: Render initial view (Pending Requests)
  loadPendingRequests();

  // Step 2: Set up sidebar navigation
  setupNavigation();
});

/**
 * Loads pending requests and renders them
 */
async function loadPendingRequests() {
  try {
    // Simulate API call (in real app: const data = await apiRequest('/requests/pending'))
    const mockRequests = [
      {
        id: 1,
        employee: 'Ana López',
        type: 'Vacaciones',
        date: '15 - 20 Oct 2025',
        status: 'Pendiente'
      },
      {
        id: 2,
        employee: 'Carlos Ruiz',
        type: 'Permiso Médico',
        date: '10 Oct 2025',
        status: 'Pendiente'
      },
      {
        id: 3,
        employee: 'Sofía Méndez',
        type: 'Licencia de Maternidad',
        date: '1 Nov 2025',
        status: 'Pendiente'
      }
    ];

    renderRequestsTable(mockRequests);
  } catch (error) {
    console.error('Failed to load pending requests:', error);
    renderError('No se pudieron cargar las solicitudes pendientes.');
  }
}

/**
 * Sets up navigation between dashboard views
 */
function setupNavigation() {
  const links = document.querySelectorAll('.sidebar-menu a');
  const logoutBtn = document.getElementById('logoutBtn');

  // Navigation links
  links.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();

      // Remove active class
      document.querySelectorAll('.sidebar-menu li').forEach(li => {
        li.classList.remove('active');
      });

      // Add active to current link
      link.parentElement.classList.add('active');

      // Get view
      const view = link.getAttribute('data-view');
      console.log('Navigating to:', view);

      // Render view
      switch (view) {
        case 'pending-requests':
          loadPendingRequests();
          break;
        case 'create-request':
          renderRequestForm();
          break;
        case 'manage-users':
          renderUserForm();
          break;
        default:
          loadPendingRequests();
      }
    });
  });

  // Logout
  logoutBtn?.addEventListener('click', handleLogout);
}

/**
 * Renders the unified request form (vacations, permissions, certificates)
 */
function renderRequestForm() {
  const container = document.getElementById('dynamic-content');
  if (!container) return;

  container.innerHTML = `
    <header class="main-header">
      <h1>Crear Nueva Solicitud</h1>
    </header>
    <section class="content-section">
      <form id="requestForm">
        <div style="margin-bottom: 15px;">
          <label>Colaborador</label>
          <input type="text" class="form-control" placeholder="Nombre del colaborador" required />
        </div>
        <div style="margin-bottom: 15px;">
          <label>Tipo de Solicitud</label>
          <select class="form-control" id="requestType" required>
            <option value="">Selecciona un tipo</option>
            <option value="vacation">Vacaciones</option>
            <option value="personal-leave">Permiso Personal</option>
            <option value="medical-leave">Permiso Médico</option>
            <option value="maternity-paternity">Licencia de Maternidad/Paternidad</option>
            <option value="compensatory">Día Compensatorio</option>
            <option value="certificate">Certificado Laboral</option>
          </select>
        </div>
        <div id="dynamicFields" style="margin-bottom: 15px;"></div>
        <div style="margin-bottom: 15px;">
          <label>Comentario (opcional)</label>
          <textarea class="form-control" rows="3" placeholder="Detalles adicionales..."></textarea>
        </div>
        <div style="margin-bottom: 15px;">
          <label>Adjuntar Soporte (opcional)</label>
          <input type="file" class="form-control" />
        </div>
        <button type="submit" class="add-btn">Enviar Solicitud</button>
      </form>
    </section>
  `;

  // Handle dynamic fields
  document.getElementById('requestType')?.addEventListener('change', (e) => {
    const type = e.target.value;
    const dynamicFields = document.getElementById('dynamicFields');
    dynamicFields.innerHTML = '';

    if (type === 'vacation' || type === 'compensatory') {
      dynamicFields.innerHTML = `
        <label>Fechas</label>
        <input type="date" class="form-control" required />
      `;
    } else if (type === 'certificate') {
      dynamicFields.innerHTML = `
        <label>Tipo de Certificado</label>
        <select class="form-control" required>
          <option value="laboral">Laboral</option>
          <option value="cesantias">Cesantías</option>
          <option value="vacaciones">Vacaciones</option>
        </select>
      `;
    } else if (type === 'medical-leave') {
      dynamicFields.innerHTML = `
        <label>Fecha del Permiso</label>
        <input type="date" class="form-control" required />
        <label>Adjuntar Certificado Médico</label>
        <input type="file" class="form-control" required />
      `;
    }
  });

  // Handle form submission
  document.getElementById('requestForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Solicitud enviada correctamente.');
    // In the future: apiRequest('/requests', { method: 'POST', body: formData })
  });
}

/**
 * Renders the user management form
 */
function renderUserForm() {
  const container = document.getElementById('dynamic-content');
  if (!container) return;

  container.innerHTML = `
    <header class="main-header">
      <h1>Gestión de Usuarios</h1>
    </header>
    <section class="content-section">
      <form id="userForm">
        <div style="margin-bottom: 15px;">
          <label>Nombre Completo</label>
          <input type="text" class="form-control" placeholder="Nombre del usuario" required />
        </div>
        <div style="margin-bottom: 15px;">
          <label>Correo</label>
          <input type="email" class="form-control" placeholder="correo@empresa.com" required />
        </div>
        <div style="margin-bottom: 15px;">
          <label>Rol</label>
          <select class="form-control" required>
            <option value="employee">Empleado</option>
            <option value="leader">Líder</option>
            <option value="hr">Talento Humano</option>
          </select>
        </div>
        <div style="margin-bottom: 15px;">
          <label>Contraseña</label>
          <input type="password" class="form-control" placeholder="Contraseña temporal" required />
        </div>
        <button type="submit" class="add-btn">Crear Usuario</button>
      </form>
    </section>
  `;

  document.getElementById('userForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Usuario creado correctamente.');
    // In the future: apiRequest('/users', { method: 'POST', body: userData })
  });
}

/**
 * Renders an error message in the dynamic content
 * @param {string} message
 */
function renderError(message) {
  const container = document.getElementById('dynamic-content');
  if (!container) return;

  container.innerHTML = `
    <div class="error" style="color: #ef4444; font-size: 1.1rem; text-align: center; margin-top: 2rem;">
      ${message}
    </div>
  `;
}

/**
 * Handles logout
 */
function handleLogout() {
  localStorage.removeItem('authToken');
  localStorage.removeItem('user');
  window.location.href = '/index.html';
}