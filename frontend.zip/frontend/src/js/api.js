/**
 * api.js - The Communications Specialist
 * This file is responsible for:
 * - All fetch calls to the backend API
 * - Centralized request handling (base URL, headers, error management)
 * - Exporting functions for each endpoint
 * It does NOT manipulate the DOM.
 */

/**
 * Centralized function for all API requests
 * @param {string} endpoint - API endpoint (e.g., '/auth/login')
 * @param {Object} options - Fetch options (method, body, headers, etc.)
 * @returns {Promise<any>} - JSON response or null if error/unauthorized
 */
export async function apiRequest(endpoint, options = {}) {
  const token = localStorage.getItem('authToken');

  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` })
    },
    ...options
  };

  // Simulamos un retraso de red
  await new Promise(resolve => setTimeout(resolve, 300));

  // Manejar autenticación
  if (endpoint === '/auth/login' && config.method === 'POST') {
    const { username, password } = JSON.parse(config.body);
    return mockLogin(username, password);
  }

  // Protección: si no hay token, redirigir al login
  if (!token) {
    window.location.href = '/index.html';
    return null;
  }

  // Simulamos respuesta de solicitudes pendientes
  if (endpoint === '/requests/pending') {
    return {
      requests: [
        {
          id: 1,
          employee: 'Ana López',
          type: 'Vacaciones',
          date: '15 - 20 Oct 2025',
          status: 'Pendiente'
        },
        {
          id: 2,
          employee: 'Carlos Ruiz',
          type: 'Permiso Médico',
          date: '10 Oct 2025',
          status: 'Pendiente'
        }
      ]
    };
  }

  // Simulamos creación de solicitud
  if (endpoint === '/requests' && config.method === 'POST') {
    return { success: true, id: Date.now() };
  }

  return {};
}

/**
 * Mock login function
 * @param {string} username
 * @param {string} password
 * @returns {Object}
 */
function mockLogin(username, password) {
  const users = {
    employee: { id: 1, username: 'employee', role: 'employee', name: 'Ana López' },
    leader: { id: 2, username: 'leader', role: 'leader', name: 'Carlos Ruiz' },
    hr: { id: 3, username: 'hr', role: 'hr', name: 'Sofía Méndez' }
  };

  const user = users[username];

  if (user && password === '1234') {
    const token = `mock-jwt.${btoa(JSON.stringify(user))}.signature`;
    return {
      token,
      user
    };
  }

  throw new Error('Invalid credentials');
}

/**
 * Logs in a user (mock)
 * @param {string} username
 * @param {string} password
 * @returns {Promise<{success: boolean, token?: string, user?: object, message?: string}>}
 */
export async function login(username, password) {
  try {
    const data = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });

    if (data && data.token && data.user) {
      return { success: true, token: data.token, user: data.user };
    } else {
      return { success: false, message: 'Invalid credentials' };
    }
  } catch (error) {
    return { success: false, message: error.message };
  }
}