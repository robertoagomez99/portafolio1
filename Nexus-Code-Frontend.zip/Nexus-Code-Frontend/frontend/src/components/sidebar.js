// src/components/sidebar.js
import { auth } from '../services/auth.js';
import { router } from '../router/router.js';

export function Sidebar() {
  const user = auth.getUser();
  if (!user) {
    console.warn('❌ No hay usuario autenticado');
    return document.createElement('aside');
  }

  const sidebar = document.createElement('aside');
  sidebar.classList.add('sidebar');

  // ✅ Forzar estilos visibles
  Object.assign(sidebar.style, {
    width: '240px',
    height: '100vh',
    background: '#f9f9f9',
    borderRight: '1px solid #ddd',
    padding: '20px 0',
    boxShadow: '2px 0 5px rgba(0,0,0,0.1)',
    display: 'flex',
    flexDirection: 'column',
    boxSizing: 'border-box'
  });

  // ✅ HTML con datos del usuario
  sidebar.innerHTML = `
    <div style="text-align: center; padding: 20px 0; margin-bottom: 20px;">
      <img 
        src="https://i.pravatar.cc/60?u=${user.email}" 
        alt="Perfil" 
        style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover; background: #ddd;"
      >
      <h3 style="margin: 10px 0; font-size: 16px; color: #333;">${user.first_name} ${user.last_name}</h3>
      <p style="color: #666; font-size: 12px;">${user.role_name || 'Empleado'}</p>
    </div>

    <div class="sidebar-menu" style="flex: 1; padding: 0 20px;">
      <ul style="list-style: none; padding: 0;">
        <li style="padding: 12px 20px; cursor: pointer; border-bottom: 1px solid #eee;">
          <a href="/dashboard" data-navigo style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 12px;">
            <i class="fa-solid fa-house"></i> Dashboard
          </a>
        </li>
        <li style="padding: 12px 20px; cursor: pointer; border-bottom: 1px solid #eee;">
          <a href="/requests/new" data-navigo style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 12px;">
            <i class="fa-solid fa-plus-circle"></i> Nueva Solicitud
          </a>
        </li>
        <li style="padding: 12px 20px; cursor: pointer; border-bottom: 1px solid #eee;">
          <a href="/requests/my" data-navigo style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 12px;">
            <i class="fa-solid fa-list"></i> Mis Solicitudes
          </a>
        </li>
      </ul>
    </div>
  `;

  // ✅ Botón de logout
  const logoutBtn = document.createElement('button');
  logoutBtn.textContent = 'Cerrar Sesión';
  logoutBtn.style.margin = '20px';
  logoutBtn.style.padding = '10px';
  logoutBtn.style.backgroundColor = '#ef4444';
  logoutBtn.style.color = 'white';
  logoutBtn.style.border = 'none';
  logoutBtn.style.borderRadius = '6px';
  logoutBtn.style.cursor = 'pointer';
  logoutBtn.onclick = () => {
    auth.logout();
    router.navigate('/login');
  };

  sidebar.appendChild(logoutBtn);

  return sidebar;
}