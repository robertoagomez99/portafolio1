// src/services/auth.js

// Usuario mock (puedes cambiar el rol para probar diferentes perfiles)
const MOCK_USER = {
  id: 'mock-001',
  first_name: 'Roberto',
  last_name: 'Gómez',
  email: 'roberto@empresa.com',
  role: 'employee',         // Cambia a 'leader' o 'hr' para probar otros roles
  role_name: 'Empleado'     // o 'Líder de Equipo', 'Talento Humano'
};

// Bandera para activar/desactivar el mock (útil para producción)
const USE_MOCK = true;

export const auth = {
  // Verifica si hay un usuario real o si se usa el mock
  isAuthenticated() {
    const hasRealUser = !!this.getUser();
    return USE_MOCK || hasRealUser;
  },

  // Devuelve el usuario real o el mock
  getUser() {
    const saved = localStorage.getItem('user');
    if (saved) {
      return JSON.parse(saved);
    }

    // Si no hay usuario real y el mock está activo, devuelve el mock
    if (USE_MOCK) {
      return MOCK_USER;
    }

    return null;
  },

  // Guarda el usuario en localStorage (para login real)
  login(userData) {
    localStorage.setItem('user', JSON.stringify(userData));
  },

  // Elimina el usuario (logout)
  logout() {
    localStorage.removeItem('user');
  }
};