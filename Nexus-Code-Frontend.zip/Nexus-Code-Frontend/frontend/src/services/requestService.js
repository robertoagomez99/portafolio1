// src/services/requestService.js
export const requestService = {
  // Obtener todas las solicitudes
  getAllRequests() {
    return JSON.parse(localStorage.getItem('requests') || '[]');
  },

  // Obtener solicitudes del equipo del líder
  getTeamRequests(leaderId) {
    const all = this.getAllRequests();
    return all.filter(req => req.leaderId === leaderId && req.status === 'pending');
  },

  // Obtener solicitudes por colaborador
  getRequestsByEmployee(employeeId) {
    const all = this.getAllRequests();
    return all.filter(req => req.employeeId === employeeId);
  },

  // Actualizar estado de una solicitud
  updateRequest(id, updates) {
    const all = this.getAllRequests();
    const request = all.find(r => r.id == id);
    if (request) {
      Object.assign(request, updates);
      localStorage.setItem('requests', JSON.stringify(all));
      return request;
    }
    return null;
  }
};