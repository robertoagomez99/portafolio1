// src/views/dashboard.js
import { auth } from '../services/auth.js';
import { router } from '../router/router.js';

export function showDashboardPage() {
  const user = auth.getUser();
  const role = user?.role || 'employee';

  // ✅ Solo el contenido del dashboard, sin sidebar ni navbar
  const container = document.createElement('div');
  container.style.margin = '0';
  container.style.minHeight = '100%';

  let title = 'Mis Solicitudes';
  let addBtnText = 'Nueva Solicitud';
  let tableHeaders = `
    <th>Fecha</th>
    <th>Tipo</th>
    <th>Estado</th>
    <th>Comentario</th>
  `;
  let tableRows = `
    <tr>
      <td>01/09/2025</td>
      <td>Vacaciones</td>
      <td><span class="status approved">Aprobado</span></td>
      <td>Descanso anual</td>
    </tr>
  `;

  if (role === 'leader') {
    title = 'Solicitudes Pendientes';
    addBtnText = 'Ver Todas';
    tableHeaders = `
      <th>Empleado</th>
      <th>Tipo</th>
      <th>Fechas</th>
      <th>Estado</th>
      <th>Acciones</th>
    `;
    tableRows = `
      <tr>
        <td>Juan Pérez</td>
        <td>Vacaciones</td>
        <td>01/09/2025 - 10/09/2025</td>
        <td><span class="status pending">Pendiente</span></td>
        <td>
          <button class="btn btn-approve">Aprobar</button>
          <button class="btn btn-reject">Rechazar</button>
        </td>
      </tr>
    `;
  }

  if (role === 'hr') {
    title = 'Gestión de Empleados';
    addBtnText = 'Agregar Empleado';
    tableHeaders = `
      <th>Empleado</th>
      <th>Email</th>
      <th>ID</th>
      <th>Fecha Ingreso</th>
      <th>Acciones</th>
    `;
    tableRows = `
      <tr>
        <td>Juan Pérez</td>
        <td>juan@empresa.com</td>
        <td>123456789</td>
        <td>01/01/2023</td>
        <td>
          <button class="btn btn-edit">Editar</button>
          <button class="btn btn-delete">Eliminar</button>
        </td>
      </tr>
    `;
  }

  container.innerHTML = `
    <div class="main-header">
      <h1>${title}</h1>
      <div class="search-box">
        <input type="text" placeholder="Buscar ${role === 'hr' ? 'empleado' : 'solicitud'}...">
        <button class="btn btn-primary">${addBtnText}</button>
      </div>
    </div>

    <div class="content-section">
      <table class="data-table">
        <thead>
          <tr>${tableHeaders}</tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>
  `;

  // ✅ Eventos
  setTimeout(() => {
    container.querySelectorAll('.btn-approve').forEach(btn => {
      btn.addEventListener('click', () => alert('Aprobado'));
    });
    container.querySelectorAll('.btn-reject').forEach(btn => {
      btn.addEventListener('click', () => alert('Rechazado'));
    });
    container.querySelectorAll('.btn-edit').forEach(btn => {
      btn.addEventListener('click', () => alert('Editar'));
    });
    container.querySelectorAll('.btn-delete').forEach(btn => {
      btn.addEventListener('click', () => confirm('¿Eliminar?') && alert('Eliminado'));
    });
  }, 100);

  return container;
}